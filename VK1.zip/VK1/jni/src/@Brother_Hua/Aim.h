std::atomic<bool> 触摸线程运行中(false);
std::thread 触摸线程;
std::mutex 触摸互斥锁;

struct 触摸瞄准参数 {
    int 屏幕方向;
    int 实际方向;
    int screenWidth;
    int screenHeight;
    ImVec2 圆位置;
    float 圆半径;
    float 瞄准平滑度;
    int 最近目标索引;
    float 屏幕中心点X;
    float 屏幕中心点Y;
    bool 持续瞄准;
    int 瞄准频率;
};

触摸瞄准参数 当前瞄准参数;

void 触摸瞄准线程函数() {
    bool isDown = false;
    double tx, ty;
    
    double ScreenX = ::abs_ScreenX;
    double ScreenY = ::abs_ScreenY;
    
    float 屏幕中心点X = ScreenX / 2.0f;
    float 屏幕中心点Y = ScreenY / 2.0f;
    
    float 触摸范围 = 当前瞄准参数.圆半径 * 0.8f;
    
    float 随机角度 = 2.0f * M_PI * (rand() % 10000) / 10000.0f;
    float 随机半径 = 当前瞄准参数.圆半径 * 0.7f * (rand() % 10000) / 10000.0f;
    float randomOffsetX = cos(随机角度) * 随机半径;
    float randomOffsetY = sin(随机角度) * 随机半径;
    
    tx = 当前瞄准参数.圆位置.x + randomOffsetX;
    ty = 当前瞄准参数.圆位置.y + randomOffsetY;
    
    int adjustedStartX, adjustedStartY;
    switch (当前瞄准参数.实际方向) {
        case 0:  // 横屏
            adjustedStartX = static_cast<int>(ScreenY - ty);
            adjustedStartY = static_cast<int>(tx);
            break;
        case 1:  // 反向横屏
            adjustedStartX = static_cast<int>(ty);
            adjustedStartY = static_cast<int>(ScreenX - tx);
            break;
        default:
            adjustedStartX = static_cast<int>(tx);
            adjustedStartY = static_cast<int>(ty);
            break;
    }
    
    Touch::Down(adjustedStartX, adjustedStartY);
    isDown = true;
    
    float 平滑因子 = 0.2f + 当前瞄准参数.瞄准平滑度 * 0.6f;
    float 上次角度 = 0.0f;
    bool 有有效角度 = false;
    
    while (触摸线程运行中.load()) {
        bool 需要瞄准 = false;
        int 目标索引 = -1;
        float target_x = 0, target_y = 0;
        
        {
            std::lock_guard<std::mutex> lock(触摸互斥锁);
            if (当前瞄准参数.持续瞄准 && 当前瞄准参数.最近目标索引 != -1) {
                需要瞄准 = true;
                目标索引 = 当前瞄准参数.最近目标索引;
                
                if (目标索引 >= 0 && 目标索引 < 地址.敌人数量) {
                    敌人数据& 敌人 = 地址.敌人列表[目标索引];
                    target_x = 敌人.屏幕坐标.X;
                    target_y = 敌人.屏幕坐标.Y;
                }
            }
        }
        
        if (!需要瞄准) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }
        
        if (target_x <= 0 || target_x >= ScreenX || target_y <= 0 || target_y >= ScreenY) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }
        
        float centerToTargetX = target_x - 屏幕中心点X;
        float centerToTargetY = target_y - 屏幕中心点Y;
        float 目标角度 = atan2(centerToTargetY, centerToTargetX);
        
        float 准心到敌人距离 = sqrt(centerToTargetX * centerToTargetX + centerToTargetY * centerToTargetY);
        if (准心到敌人距离 < 10.0f) {
            std::this_thread::sleep_for(std::chrono::milliseconds(当前瞄准参数.瞄准频率));
            continue;
        }
        
        if (有有效角度) {
            float 角度差 = 目标角度 - 上次角度;
            if (角度差 > M_PI) 角度差 -= 2.0f * M_PI;
            if (角度差 < -M_PI) 角度差 += 2.0f * M_PI;
            
            目标角度 = 上次角度 + 角度差 * 平滑因子;
        } else {
            有有效角度 = true;
        }
        上次角度 = 目标角度;
        
        float targetDistance = sqrt(centerToTargetX * centerToTargetX + centerToTargetY * centerToTargetY);
        
        float slideDistance = targetDistance * (1.0f - 当前瞄准参数.瞄准平滑度) * 0.05f;
        
        slideDistance = std::max(slideDistance, 1.0f);
        slideDistance = std::min(slideDistance, 当前瞄准参数.圆半径 * 0.08f);
        
        double new_tx = tx + cos(目标角度) * slideDistance;
        double new_ty = ty + sin(目标角度) * slideDistance;
        
        float distanceFromCenter = sqrt(
            pow(new_tx - 当前瞄准参数.圆位置.x, 2) + 
            pow(new_ty - 当前瞄准参数.圆位置.y, 2)
        );
        
        if (distanceFromCenter > 当前瞄准参数.圆半径) {
            if (isDown) {
                Touch::Up();
                isDown = false;
            }
            
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
            
            随机角度 = 2.0f * M_PI * (rand() % 10000) / 10000.0f;
            随机半径 = 当前瞄准参数.圆半径 * 0.7f * (rand() % 10000) / 10000.0f;
            randomOffsetX = cos(随机角度) * 随机半径;
            randomOffsetY = sin(随机角度) * 随机半径;
            
            tx = 当前瞄准参数.圆位置.x + randomOffsetX;
            ty = 当前瞄准参数.圆位置.y + randomOffsetY;
            
            有有效角度 = false;
            
            int adjustedStartX, adjustedStartY;
            switch (当前瞄准参数.实际方向) {
                case 0:  // 横屏
                    adjustedStartX = static_cast<int>(ScreenY - ty);
                    adjustedStartY = static_cast<int>(tx);
                    break;
                case 1:  // 反向横屏
                    adjustedStartX = static_cast<int>(ty);
                    adjustedStartY = static_cast<int>(ScreenX - tx);
                    break;
                default:
                    adjustedStartX = static_cast<int>(tx);
                    adjustedStartY = static_cast<int>(ty);
                    break;
            }
            
            Touch::Down(adjustedStartX, adjustedStartY);
            isDown = true;
        } else {
            tx = new_tx;
            ty = new_ty;
            
            int adjustedTargetX, adjustedTargetY;
            switch (当前瞄准参数.实际方向) {
                case 0:  // 横屏
                    adjustedTargetX = static_cast<int>(ScreenY - ty);
                    adjustedTargetY = static_cast<int>(tx);
                    break;
                case 1:  // 反向横屏
                    adjustedTargetX = static_cast<int>(ty);
                    adjustedTargetY = static_cast<int>(ScreenX - tx);
                    break;
                default:
                    adjustedTargetX = static_cast<int>(tx);
                    adjustedTargetY = static_cast<int>(ty);
                    break;
            }
            
            if (!isDown) {
                Touch::Down(adjustedTargetX, adjustedTargetY);
                isDown = true;
            } else {
                Touch::Move(adjustedTargetX, adjustedTargetY);
            }
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(当前瞄准参数.瞄准频率));
    }
    
    if (isDown) {
        Touch::Up();
    }
}

void 启动触摸线程() {
    if (!触摸线程运行中.load()) {
        触摸线程运行中.store(true);
        触摸线程 = std::thread(触摸瞄准线程函数);
    }
}

void 停止触摸线程() {
    if (触摸线程运行中.load()) {
        触摸线程运行中.store(false);
        if (触摸线程.joinable()) {
            触摸线程.join();
        }
    }
}