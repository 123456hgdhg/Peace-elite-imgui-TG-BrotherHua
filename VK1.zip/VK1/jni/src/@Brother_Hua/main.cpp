#include "TouchHelperA.h"
#include "draw.h"
#include "timer.h"
#include "AndroidImgui.h"
#include "GraphicsManager.h"
#include "驱动读写.h"
#include "数据.h"
#include "Aim.h"
#include "UI.h"
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/prctl.h>

float 最大显示距离 = 350.0f;
int 目标FPS = 60;
bool FPS限制启用 = true;
timer 主循环计时器;

// 改进的独立进程创建 - 不关闭图形相关文件描述符
void 创建独立进程() {
    pid_t pid = fork();
    if (pid < 0) {
        return;
    }
    
    if (pid > 0) {
        // 父进程退出
        exit(0);
    }
    
    // 子进程创建新会话
    setsid();
    
    // 不进行第二次fork，保持图形能力
    umask(0);
    chdir("/data/local/tmp");
    
    // 只关闭标准IO，不关闭其他文件描述符（包括图形相关的）
    int null_fd = open("/dev/null", O_RDWR);
    if (null_fd != -1) {
        dup2(null_fd, STDIN_FILENO);
        dup2(null_fd, STDOUT_FILENO);
        dup2(null_fd, STDERR_FILENO);
        if (null_fd > STDERR_FILENO) {
            close(null_fd);
        }
    }
    
    // 设置进程名称
    prctl(PR_SET_NAME, "TG_ESP_Service", 0, 0, 0);
}

// 信号处理
void 忽略终端信号() {
    signal(SIGHUP, SIG_IGN);
    signal(SIGINT, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
}

// 安全退出函数
void 安全退出() {
    停止触摸线程();
    running = false;
    
    // 给线程时间清理
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    
    if (graphics) {
        graphics->Shutdown();
    }
    if (::window) {
        android::ANativeWindowCreator::Destroy(::window);
    }
    
    _exit(0);
}

// 信号处理
void 信号处理(int sig) {
    switch(sig) {
        case SIGTERM:
            安全退出();
            break;
    }
}

// 检查图形环境是否有效
bool 检查图形环境() {
    return ::graphics != nullptr && ::window != nullptr;
}

// 初始化图形环境
bool 初始化图形环境() {
    ::graphics = GraphicsManager::getGraphicsInterface(GraphicsManager::VULKAN);
    if (!::graphics) {
        return false;
    }
    
    ::screen_config();

    ::native_window_screen_x = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::native_window_screen_y = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::abs_ScreenX = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::abs_ScreenY = (::displayInfo.height < ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);

    ::window = android::ANativeWindowCreator::Create("TG_ESP_Overlay", native_window_screen_x, native_window_screen_y, permeate_record);
    if (!::window) {
        return false;
    }
    
    if (!graphics->Init_Render(::window, native_window_screen_x, native_window_screen_y)) {
        return false;
    }

    Touch::Init({(float)::abs_ScreenX, (float)::abs_ScreenY}, false);
    Touch::setOrientation(displayInfo.orientation);

    ::init_My_drawdata();
    
    return true;
}

int main(int argc, char* argv[]) {
    // 程序启动时自动创建独立进程
    创建独立进程();
    
    // 忽略终端信号
    忽略终端信号();
    
    // 设置信号处理
    signal(SIGTERM, 信号处理);

    // 初始化图形环境 - 在进程分离后进行
    if (!初始化图形环境()) {
        // 图形初始化失败，退出
        _exit(1);
    }

    bool flag = true;
    int 重试计数 = 0;
    const int 最大重试次数 = 3;

    while (flag && running) {
        // 检查图形环境
        if (!检查图形环境()) {
            重试计数++;
            if (重试计数 >= 最大重试次数) {
                // 尝试重新初始化图形环境
                if (!初始化图形环境()) {
                    // 重新初始化失败，退出
                    break;
                }
                重试计数 = 0;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            continue;
        }
        重试计数 = 0;

        if (FPS限制启用 && 目标FPS > 0) {
            static bool 首次调用 = true;
            if (首次调用) {
                主循环计时器.start();
                首次调用 = false;
            } else {
                long long 每帧时间 = 1000000000 / 目标FPS;
                long long 实际用时 = 主循环计时器.stop() * 1000000;
                if (实际用时 < 每帧时间) {
                    主循环计时器.nsleep(每帧时间 - 实际用时);
                }
                主循环计时器.start();
            }
        }

        // 获取游戏数据
        GetBase();

        // 渲染
        if (检查图形环境()) {
            drawBegin();
            graphics->NewFrame();
            Layout_tick_UI(&flag);
            graphics->EndFrame();
        } else {
            // 图形环境失效，短暂等待
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
        
        // 防止过度占用CPU
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    安全退出();
    return 0;
}