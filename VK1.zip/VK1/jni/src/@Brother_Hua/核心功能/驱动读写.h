
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <iostream>

class c_driver {
private:
    int fd;
    pid_t pid;
    char *derive;

    typedef struct _COPY_MEMORY {
        pid_t pid;
        uintptr_t addr;
        void* buffer;
        size_t size;
    } COPY_MEMORY, *PCOPY_MEMORY;

    typedef struct _MODULE_BASE {
        pid_t pid;
        char* name;
        uintptr_t base;
    } MODULE_BASE, *PMODULE_BASE;

    enum OPERATIONS {
        OP_INIT_KEY = 0x800,
        OP_READ_MEM = 0x801,
        OP_WRITE_MEM = 0x802,
        OP_MODULE_BASE = 0x803,
    };
    
    char *driver_path() {
        const char *dev_path = "/dev";
        DIR *dir = opendir(dev_path);
        if (dir == NULL){
            printf("无法打开/dev目录\n");
            return NULL;
        }

        struct dirent *entry;
        static char file_path[256];
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }
            sprintf(file_path, "%s/%s", dev_path, entry->d_name);
            struct stat file_info;
            if (stat(file_path, &file_info) < 0) {
                continue;
            }
            
            if (strstr(entry->d_name, "gpiochip") != NULL) {
                continue;
            }

            if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
                && strchr(entry->d_name, '_') == NULL
                && strchr(entry->d_name, '-') == NULL
                && strchr(entry->d_name, ':') == NULL) {
                if (strcmp(entry->d_name, "stdin") == 0
                || strcmp(entry->d_name, "stdout") == 0
                || strcmp(entry->d_name, "stderr") == 0) {
                    continue;
                }
                
                size_t file_name_length = strlen(entry->d_name);
                time_t current_time;
                time(&current_time);
                int current_year = localtime(&current_time)->tm_year + 1900;
                int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
                if (file_year <= 1980) {
                    continue;
                }
                
                time_t atime = file_info.st_atime;
                time_t ctime = file_info.st_ctime;
                if (atime == ctime) {
                    if ((file_info.st_mode & S_IFMT) == 8192
                    && file_info.st_size == 0
                    && file_info.st_gid == 0
                    && file_info.st_uid == 0
                    && file_name_length <= 6) {
                        derive = file_path;
                        closedir(dir);
                        return file_path;
                    }
                }
            }
        }
        closedir(dir);
        return NULL;
    }
    
    char* qx()
    {
        const char* command = "dir=$(ls -l /proc/*/exe 2>/dev/null | grep -E '/data/[^/]* \\(deleted\\)' | sed 's/ /\\n/g' | grep '/proc' | sed 's/\\/[^/]*$//g');if [[ \"$dir\" ]]; then sbwj=$(head -n 1 \"$dir/comm\");open_file=\"\";for file in \"$dir\"/fd/*; do link=$(readlink \"$file\");if [[ \"$link\" == \"/dev/$sbwj (deleted)\" ]]; then open_file=\"$file\";break;fi;done;if [[ -n \"$open_file\" ]]; then nhjd=$(echo \"$open_file\");sbid=$(ls -L -l \"$nhjd\" | sed 's/\\([^,]*\\).*/\\1/' | sed 's/.*root //');echo \"/dev/$sbwj\";rm -rf \"/dev/$sbwj\";mknod \"/dev/$sbwj\" c \"$sbid\" 0;fi;fi;";
        FILE* file = popen(command, "r");
        if (file == NULL) {
            return NULL;
        }
        static char result[512];
        if (fgets(result, sizeof(result), file) == NULL) {
            return NULL;
        }
        pclose(file);
        result[strlen(result)-1] = '\0';
        derive = result;
        return result;
    }
    
    int open_driver() {
        char *dev_path3 = qx();
        if (dev_path3 != NULL) {
            fd = open(dev_path3, O_RDWR);
            if (fd>0){
                printf("隐藏驱动：%s\n", dev_path3);
                unlink(dev_path3);
                return 1;
            }
        }
        char *dev_path1 = driver_path();
        if (dev_path1 != NULL) {
            fd = open(dev_path1, O_RDWR);
            if (fd>0){
                printf("驱动文件：%s\n", dev_path1);
                return 1;
            }
        }
        return 0;
    }

    // 新增的辅助函数
    char *execCom(const char *shell) {
        FILE *fp = popen(shell, "r");
        if (fp == NULL) {
            perror("popen failed");
            return NULL;
        }
        char buffer[256];
        char *result = (char *)malloc(1000);
        result[0] = '\0';
        while (fgets(buffer, sizeof(buffer), fp) != NULL) {
            strcat(result, buffer);
        }
        pclose(fp);
        return result;
    }

    void createDriverNode(char *path, int major_number, int minor_number) {
        std::string command = "mknod " + std::string(path) + " c " + std::to_string(major_number) + " " + std::to_string(minor_number);
        system(command.c_str());
        printf("[-]创建 %s\n[-]主设备号：%d\n[-]次设备号：%d\n", path, major_number, minor_number);
    }

    void removeDeviceNode(char* path) {
        printf("%s\n",path);
        if (unlink(path) == 0) {
            printf("[-]驱动安全守护已激活\n");
        } else {
            printf("[-]驱动安全守护执行错误\n");
        }
    }

    const char* get_dev() {
        const char* command = "for dir in /proc/*/; do cmdline_file=\"cmdline\"; comm_file=\"comm\"; proclj=\"$dir$cmdline_file\"; proclj2=\"$dir$comm_file\"; if [[ -f \"$proclj\" && -f \"$proclj2\" ]]; then cmdline=$(head -n 1 \"$proclj\"); comm=$(head -n 1 \"$proclj2\"); if echo \"$cmdline\" | grep -qE '^/data/[a-z]{6}$'; then sbwj=$(echo \"$comm\"); open_file=\"\"; for file in \"$dir\"/fd/*; do link=$(readlink \"$file\"); if [[ \"$link\" == \"/dev/$sbwj (deleted)\" ]]; then open_file=\"$file\"; break; fi; done; if [[ -n \"$open_file\" ]]; then nhjd=$(echo \"$open_file\"); sbid=$(ls -L -l \"$nhjd\" | sed 's/\\([^,]*\\).*/\\1/' | sed 's/.*root //'); echo \"/dev/$sbwj\"; rm -Rf \"/dev/$sbwj\"; mknod \"/dev/$sbwj\" c \"$sbid\" 0; break; fi; fi; fi; done";
        FILE* file = popen(command, "r");
        if (file == NULL) {
            return NULL;
        }
        char result[512];
        if (fgets(result, sizeof(result), file) == NULL) {
            pclose(file);
            return NULL;
        }
        pclose(file);
        int len = strlen(result);
        if (len > 0 && result[len - 1] == '\n') {
            result[len - 1] = '\0';
        }
        return strdup(result);
    }

    char *gtqwq() {
        const char *dev_path = "/dev";
        DIR *dir = opendir(dev_path);
        if (dir == NULL){
            printf("无法打开/dev目录\n");
            return NULL;
        }
        const char *files[] = { "wanbai", "CheckMe", "Ckanri", "lanran","video188"};
        struct dirent *entry;
        char *gtfile_path = NULL;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }
            size_t path_length = strlen(dev_path) + strlen(entry->d_name) + 2;
            gtfile_path = (char *)malloc(path_length);
            snprintf(gtfile_path, path_length, "%s/%s", dev_path, entry->d_name);
            for (int i = 0; i < 5; i++) {
                if (strcmp(entry->d_name, files[i]) == 0) {
                    printf("驱动文件：%s\n", gtfile_path);
                    closedir(dir);
                    return gtfile_path;
                }
            }
            struct stat file_info;
            if (stat(gtfile_path, &file_info) < 0) {
                free(gtfile_path);
                gtfile_path = NULL;
                continue;
            }
            if (strstr(entry->d_name, "gpiochip") != NULL) {
                free(gtfile_path);
                gtfile_path = NULL;
                continue;
            }
            if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
                && strchr(entry->d_name, '_') == NULL && strchr(entry->d_name, '-') == NULL && strchr(entry->d_name, ':') == NULL) {
                if (strcmp(entry->d_name, "stdin") == 0 || strcmp(entry->d_name, "stdout") == 0
                    || strcmp(entry->d_name, "stderr") == 0) {
                    free(gtfile_path);
                    gtfile_path = NULL;
                    continue;
                }
                size_t file_name_length = strlen(entry->d_name);
                time_t current_time;
                time(&current_time);
                int current_year = localtime(&current_time)->tm_year + 1900;
                int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
                if (file_year <= 1980) {
                    free(gtfile_path);
                    gtfile_path = NULL;
                    continue;
                }
                time_t atime = file_info.st_atime;
                time_t ctime = file_info.st_ctime;
                if ((atime = ctime)) {
                    if ((file_info.st_mode & S_IFMT) == 8192 && file_info.st_size == 0
                        && file_info.st_gid == 0 && file_info.st_uid == 0 && file_name_length <= 9) {
                        printf("驱动文件：%s\n", gtfile_path);
                        closedir(dir);
                        return gtfile_path;
                    }
                }
            }
            free(gtfile_path);
            gtfile_path = NULL;
        }
        closedir(dir);
        return NULL;
    }

    char *find_driver_path() {
        const char *dev_path = "/dev";
        DIR *dir = opendir(dev_path);
        if (dir == NULL){
            printf("- 无法打开/dev驱动目录\n");
            return NULL;
        }
        const char *files[] = {"wanbai","CheckMe","Ckanri","lanran","video188"};
        struct dirent *entry;
        char *file_path = NULL;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0 || strcmp(entry->d_name, "wanbai") == 0 || strcmp(entry->d_name, "CheckMe") == 0 || strcmp(entry->d_name, "facking") == 0 || strcmp(entry->d_name, "vndbinder") == 0 || strcmp(entry->d_name, "YBBBYN") == 0) {
                continue;
            }
            size_t path_length = strlen(dev_path) + strlen(entry->d_name) + 2;
            file_path = (char *)malloc(path_length);
            snprintf(file_path, path_length, "%s/%s", dev_path, entry->d_name);
            for (int i = 0; i < 5; i++) {
                if (strcmp(entry->d_name, files[i]) == 0) {
                    printf("- 第一方案锁定驱动文件：%s\n", file_path);
                    closedir(dir);
                    return file_path;
                }
            }
            struct stat file_info;
            if (stat(file_path, &file_info) < 0) {
                free(file_path);
                file_path = NULL;
                continue;
            }
            if (strstr(entry->d_name, "gpiochip") != NULL) {
                free(file_path);
                file_path = NULL;
                continue;
            }
            if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
                && strchr(entry->d_name, '_') == NULL && strchr(entry->d_name, '-') == NULL && strchr(entry->d_name, ':') == NULL) {
                if (strcmp(entry->d_name, "stdin") == 0 || strcmp(entry->d_name, "stdout") == 0
                    || strcmp(entry->d_name, "stderr") == 0) {
                    free(file_path);
                    file_path = NULL;
                    continue;
                }
                size_t file_name_length = strlen(entry->d_name);
                time_t current_time;
                time(&current_time);
                int current_year = localtime(&current_time)->tm_year + 1900;
                int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
                if (file_year <= 1980) {
                    free(file_path);
                    file_path = NULL;
                    continue;
                }
                time_t atime = file_info.st_atime;
                time_t ctime = file_info.st_ctime;
                if (atime == ctime) {
                    if ((file_info.st_mode & S_IFMT) == 8192 && file_info.st_size == 0
                        && file_info.st_gid == 0 && file_info.st_uid == 0 && file_name_length <= 9) {
                        printf("- 第一方案锁定驱动文件：%s\n", file_path);
                        closedir(dir);
                        return file_path;
                    }
                }
            }
            free(file_path);
            file_path = NULL;
        }
        closedir(dir);
        return NULL;
    }

    char *driver_path_alt() {
        struct dirent *de;
        DIR *dr = opendir("/proc");
        char *device_path = NULL;
        if (dr == NULL) {
            printf("- Could not open /proc directory");
            return NULL;
        }
        while ((de = readdir(dr)) != NULL) {
            if (strlen(de->d_name) != 8 || strcmp(de->d_name, "zoneinfo") == 0 || strcmp(de->d_name, "softirqs") == 0 || strcmp(de->d_name, "kallsyms") == 0 || strcmp(de->d_name, "consoles") == 0 || strcmp(de->d_name, "vmstat") == 0 || strcmp(de->d_name, "uptime") == 0 || strcmp(de->d_name, "NVTSPI") == 0 || strcmp(de->d_name, "aputag") == 0 || strcmp(de->d_name, "asound") == 0 || strcmp(de->d_name, "clkdbg") == 0 || strcmp(de->d_name, "crypto") == 0 || strcmp(de->d_name, "mounts") == 0 || strcmp(de->d_name, "pidmap") == 0 || strcmp(de->d_name, "bootprof") == 0) {
                continue;
            }
            int is_valid = 1;
            for (int i = 0; i < 8; i++) {
                if (!isalnum(de->d_name[i])) {
                    is_valid = 0;
                    break;
                }
            }
            if (is_valid) {
                device_path = (char*)malloc(11 + strlen(de->d_name));
                printf("- 第二方案锁定驱动文件:");
                sprintf(device_path, "/proc/%s", de->d_name);
                struct stat sb;
                if (stat(device_path, &sb) == 0 && S_ISREG(sb.st_mode)) {
                    break;
                } else {
                    free(device_path);
                    device_path = NULL;
                }
            }
        }
        puts(device_path);
        closedir(dr);
        return device_path;
    }

public:
    char *drive_path = NULL;
    
    c_driver() {
        printf("\033[95m\n");
        printf("@華兄\n");
        
        // 提供多种驱动打开方式
        printf("\033[91m");
        printf("\n欢迎"); 
        
        printf("\n[1]QX驱动1(读取慢,兼容性高)"); 
        printf("\n[2]GT驱动");
        printf("\n[3]rt-dev");
        printf("\n[4]rt-proc");
        printf("\n[5]QX驱动2");
        int 选择值;
        printf("\n[-]请输入序号");
        scanf("%d",&选择值);
        
        if (选择值 ==1){
            const char* dev_path = get_dev();
            if (dev_path) {
                fd = open(dev_path, O_RDWR);
                if (fd>0){
                    printf("驱动文件：%s\n", dev_path);
                    unlink(dev_path);
                } else {
                    printf("无法找到驱动文件！\n");
                    exit(0);
                }
                free((void*)dev_path);
            } else {
                printf("无法找到驱动文件！\n");
                exit(0);
            }
        }
        else if (选择值 ==2){
            char *device_name = gtqwq();
            if (device_name) {
                fd = open(device_name, O_RDWR);
                if (fd == -1) {
                    printf("[-] 打开驱动程序失败，请重新刷入gt驱动\n");
                    free(device_name);
                    exit(0);
                }
                free(device_name);
            } else {
                printf("[-] 找不到GT驱动\n");
                exit(0);
            }
        }
        else if (选择值 ==3){
            char *device_name = find_driver_path();
            if (!device_name) {
                device_name = find_driver_path();
            }
            if (!device_name) {
                fprintf(stderr, "[-] 找不到驱动\n");
                exit(EXIT_FAILURE);
            }
            fd = open(device_name, O_RDWR);
            free(device_name);
            if (fd == -1) {
                perror("[-] 打开失败");
                exit(EXIT_FAILURE);
            }
        }
        else if (选择值 ==4){
            char *device_name = driver_path_alt();
            if (!device_name) {
                fprintf(stderr, "未找到驱动文件\n");
                exit(EXIT_FAILURE);
            }
            fd = open(device_name, O_RDWR);
            free(device_name);
            if (fd == -1) {
                perror("[-] 链接驱动失败");
                exit(EXIT_FAILURE);
            }
        }  
        else if (选择值 ==5){
            char *output = execCom("ls -l /proc/*/exe 2>/dev/null | grep -E \"/data/[a-z]{6} \\(deleted\\)\"");
            char filePath[256];
            char pid[56];
            if (output != NULL) {
                printf("调试输出:%s", output);
                char *procStart = strstr(output, "/proc/");
                if (procStart) {
                    char *pidStart = procStart + 6;
                    char *pidEnd = strchr(pidStart, '/');
                    if (pidEnd) {
                        strncpy(pid, pidStart, pidEnd - pidStart);
                        pid[pidEnd - pidStart] = '\0';
                    }
                }
                char *arrowStart = strstr(output, "->");
                if (arrowStart) {
                    char *start = arrowStart + 3;
                    char *end = strchr(output, '(');
                    if (end) {
                        end--;
                        strncpy(filePath, start, end - start + 1);
                        filePath[end - start] = '\0';
                    }
                }
                char *replacePtr = strstr(filePath, "data");
                if (replacePtr != NULL) {
                    memmove(replacePtr + 2, replacePtr + 3, strlen(replacePtr + 3) + 1);
                    memmove(replacePtr, "dev", strlen("dev"));
                }
                free(output);
            } else {
                printf("执行脚本时出错\n");
                exit(0);
            }
            
            char cmd[256];
            sprintf(cmd, "ls -al -L /proc/%s/fd/3", pid);
            char *fdInfo = execCom(cmd);
            int major_number, minor_number;
            if (fdInfo) {
                sscanf(fdInfo, "%*s %*d %*s %*s %d, %d", &major_number, &minor_number);
                free(fdInfo);
            }
            
            if (strcmp(filePath, "0") != 0) {
                createDriverNode(filePath, major_number, minor_number);
            }
            sleep(1);
            fd = open(filePath, O_RDWR);
            if (fd == -1) {
                printf("\033[31m[X] 驱动连接失败 \033[0m\n");
                printf("%s", "\n[-]QXv10 不支持换v8\n");
                exit(0);
            } else {
                printf("%s", "[+]链接成功\n");
                printf("[-] 驱动文件：%s\n",filePath);
                removeDeviceNode(filePath);
            }
        }
        else {
            // 默认使用原始方法
            if (!open_driver()) {
                printf("没有驱动文件\n");
                exit(0);
            }
        }
        
        drive_path = derive;
    }

    ~c_driver() {
        if (fd > 0)
            close(fd);
    }

    // 初始化PID
    void initialize(pid_t pid) {
        this->pid = pid;
    }

    // 读取内存
    bool Read(uintptr_t addr, void *buffer, size_t size) {
        COPY_MEMORY cm;
        cm.pid = this->pid;
        cm.addr = addr;
        cm.buffer = buffer;
        cm.size = size;
        if (ioctl(fd, OP_READ_MEM, &cm) != 0) {
            return false;
        }
        return true;
    }

    // 模板读取
    template <typename T>
    T Read(uintptr_t addr) {
        T res;
        if (this->Read(addr, &res, sizeof(T)))
            return res;
        return {};
    }

    // 写入内存
    bool Write(uintptr_t addr, void* buffer, size_t size) {
        COPY_MEMORY cm;
        cm.pid = this->pid;
        cm.addr = addr;
        cm.buffer = buffer;
        cm.size = size;
        if (ioctl(fd, OP_WRITE_MEM, &cm) != 0) {
            return false;
        }
        return true;
    }

    // 模板写入
    template <typename T>
    bool Write(uintptr_t addr, T value) {
        return this->Write(addr, &value, sizeof(T));
    }

    // 初始化密钥
    bool initKey(const char* key) {
        if (ioctl(fd, OP_INIT_KEY, key) != 0) {
            return false;
        }
        return true;
    }

    // 获取进程PID
    int getPID(const char *packageName) { 
        int id = -1; 
        DIR *dir; 
        FILE *fp; 
        char filename[64]; 
        char cmdline[64]; 
        struct dirent *entry; 
        dir = opendir("/proc"); 
        while ((entry = readdir(dir)) != NULL) { 
            id = atoi(entry->d_name); 
            if (id != 0) { 
                sprintf(filename, "/proc/%d/cmdline", id); 
                fp = fopen(filename, "r"); 
                if (fp) { 
                    fgets(cmdline, sizeof(cmdline), fp); 
                    fclose(fp); 
                    if (strcmp(packageName, cmdline) == 0) { 
                        closedir(dir);
                        return id; 
                    } 
                } 
            } 
        } 
        closedir(dir); 
        return -1; 
    }

    // 获取模块基址 - 通过maps文件
    uintptr_t get_module_base(int pid, const char *module_name) { 
        FILE *fp; 
        long addr = 0; 
        char *pch; 
        char filename[64]; 
        char line[1024]; 
        snprintf(filename, sizeof(filename), "/proc/%d/maps", pid); 
        fp = fopen(filename, "r"); 
        if (fp != NULL) { 
            while (fgets(line, sizeof(line), fp)) { 
                if (strstr(line, module_name)) { 
                    pch = strtok(line, "-"); 
                    addr = strtoul(pch, NULL, 16); 
                    if (addr == 0x8000) addr = 0; 
                    break; 
                } 
            } 
            fclose(fp); 
        } 
        return addr; 
    }

    // 获取模块基址 - 通过ioctl
    uintptr_t getModuleBase(const char* name) {
        MODULE_BASE mb;
        mb.pid = this->pid;
        mb.name = strdup(name);
        if (ioctl(fd, OP_MODULE_BASE, &mb) != 0) {
            free(mb.name);
            return 0;
        }
        uintptr_t base = mb.base;
        free(mb.name);
        return base;
    }
};

// 将全局实例改为 Core 以匹配数据.h中的调用
static c_driver *Core = new c_driver();
