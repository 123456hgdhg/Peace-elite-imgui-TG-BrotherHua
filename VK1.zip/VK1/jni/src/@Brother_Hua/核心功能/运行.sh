cd ../../../../
/data/data/com.aide.ui/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build -j20
rm -f "/data/lost+found/IMGUI"
cp libs/arm64-v8a/* /data/lost+found/IMGUI
chmod 777 /data/lost+found/IMGUI
/data/lost+found/IMGUI
rm -f "/data/lost+found/IMGUI"