
bool running = true;

extern float 最大显示距离;

struct 坐标 {
    float X;
    float Y;
    float Z;
};

struct 屏幕坐标 {
    float X;
    float Y;
};

struct 骨骼数据 {
    坐标 位置;
    bool 在屏幕上;
    屏幕坐标 屏幕坐标;
};

struct 敌人数据 {
    uintptr_t 对象地址;
    uintptr_t 名字;
    float 瞄准向量;
    float 距离;
    int 队伍;
    int isboot;
    int 状态;
    int 子弹数量;
    int 子弹最大数量;      
    float 当前血量;
    float 最大血量;
    坐标 世界坐标;
    屏幕坐标 屏幕坐标;
    
    骨骼数据 骨骼数组[1000];
    int 骨骼数量;
    char 类名[64];
    
    // 添加手持武器成员
    int 手持;
};

// 添加被瞄预警结构体
struct 被瞄信息 {
    float 距离;
    uintptr_t 名字;
    int 瞄准武器;
    char 武器名称[32];
    int 瞄准部位;
    char 敌人名字[64];
};

struct FQuat {
    float X;
    float Y;
    float Z;
    float W;
};

struct FVector {
    float X;
    float Y;
    float Z;
};

struct FTransform {
    FQuat Rotation;
    FVector Translation;
    float Unknown1;
    FVector Scale3D;
    float Unknown2;
};

struct FMatrix {
    float M[4][4];
};

// 添加FRotator结构体
struct FRotator {
    float Pitch;
    float Yaw;
    float Roll;
    
    void Clamp() {
        while (Yaw > 180.0f) Yaw -= 360.0f;
        while (Yaw < -180.0f) Yaw += 360.0f;
        while (Pitch > 180.0f) Pitch -= 360.0f;
        while (Pitch < -180.0f) Pitch += 360.0f;
    }
};

void QuatToMatrix(const FQuat& Q, FMatrix& Matrix) {
    float x2 = Q.X + Q.X;
    float y2 = Q.Y + Q.Y;
    float z2 = Q.Z + Q.Z;
    
    float xx2 = Q.X * x2;
    float yy2 = Q.Y * y2;
    float zz2 = Q.Z * z2;
    
    float yz2 = Q.Y * z2;
    float wx2 = Q.W * x2;
    float xy2 = Q.X * y2;
    float wz2 = Q.W * z2;
    float xz2 = Q.X * z2;
    float wy2 = Q.W * y2;
    
    Matrix.M[0][0] = (1.0f - (yy2 + zz2));
    Matrix.M[0][1] = (xy2 + wz2);
    Matrix.M[0][2] = (xz2 - wy2);
    Matrix.M[0][3] = 0.0f;
    
    Matrix.M[1][0] = (xy2 - wz2);
    Matrix.M[1][1] = (1.0f - (xx2 + zz2));
    Matrix.M[1][2] = (yz2 + wx2);
    Matrix.M[1][3] = 0.0f;
    
    Matrix.M[2][0] = (xz2 + wy2);
    Matrix.M[2][1] = (yz2 - wx2);
    Matrix.M[2][2] = (1.0f - (xx2 + yy2));
    Matrix.M[2][3] = 0.0f;
    
    Matrix.M[3][0] = 0.0f;
    Matrix.M[3][1] = 0.0f;
    Matrix.M[3][2] = 0.0f;
    Matrix.M[3][3] = 1.0f;
}

void MatrixMultiply(FMatrix& Result, const FMatrix& A, const FMatrix& B) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            Result.M[i][j] = 0.0f;
            for (int k = 0; k < 4; k++) {
                Result.M[i][j] += A.M[i][k] * B.M[k][j];
            }
        }
    }
}

FMatrix TransformToMatrix(const FTransform& Transform) {
    FMatrix RotationMatrix;
    QuatToMatrix(Transform.Rotation, RotationMatrix);
    
    RotationMatrix.M[0][0] *= Transform.Scale3D.X;
    RotationMatrix.M[0][1] *= Transform.Scale3D.X;
    RotationMatrix.M[0][2] *= Transform.Scale3D.X;
    
    RotationMatrix.M[1][0] *= Transform.Scale3D.Y;
    RotationMatrix.M[1][1] *= Transform.Scale3D.Y;
    RotationMatrix.M[1][2] *= Transform.Scale3D.Y;
    
    RotationMatrix.M[2][0] *= Transform.Scale3D.Z;
    RotationMatrix.M[2][1] *= Transform.Scale3D.Z;
    RotationMatrix.M[2][2] *= Transform.Scale3D.Z;
    
    RotationMatrix.M[3][0] = Transform.Translation.X;
    RotationMatrix.M[3][1] = Transform.Translation.Y;
    RotationMatrix.M[3][2] = Transform.Translation.Z;
    RotationMatrix.M[3][3] = 1.0f;
    
    return RotationMatrix;
}

struct 基础 {
    char *Kernel_drive_path;
    pid_t pid = -1;
    uintptr_t libUE4;
    uintptr_t 世界;
    uintptr_t 自身;
    uintptr_t 矩阵_0;
    uintptr_t 矩阵_1;
    uintptr_t 数组;
    uintptr_t Gname;
    int 数组数量;
    uintptr_t 物质类;
    
    struct 自身数据 {
        坐标 坐标;
        屏幕坐标 屏幕坐标;
        float 矩阵[16];
        float FOV;
        float 子弹速度;
        float 后坐力数据;
        float 准星Y;
        float 人物高度;
        float 当前血量;
        float 最大血量;
        uintptr_t 名字;
        
        int 子弹数量;
        int 子弹最大数量;
        int 手持握把;
        int 状态;
        int 开镜;
        int 开火;
        int 手持;        
    } 自身数据;
    
    敌人数据 敌人列表[1000];
    int 敌人数量;
    
    // 添加被瞄预警相关字段
    被瞄信息 被瞄信息列表[100];
    int 被瞄数量;
};

基础 地址;

bool WorldToScreen(坐标 世界坐标, float* 矩阵, float& 屏幕X, float& 屏幕Y, int 屏幕宽度, int 屏幕高度) {
    float w = 
        矩阵[3] * 世界坐标.X + 
        矩阵[7] * 世界坐标.Y + 
        矩阵[11] * 世界坐标.Z + 
        矩阵[15];
    
    if (w < 0.1f) {
        return false;
    }
    
    float x = 
        矩阵[0] * 世界坐标.X + 
        矩阵[4] * 世界坐标.Y + 
        矩阵[8] * 世界坐标.Z + 
        矩阵[12];
    float y = 
        矩阵[1] * 世界坐标.X + 
        矩阵[5] * 世界坐标.Y + 
        矩阵[9] * 世界坐标.Z + 
        矩阵[13];
    
    float inv_w = 1.0f / w;
    x *= inv_w;
    y *= inv_w;
    
    屏幕X = (x + 1.0f) * 0.5f * 屏幕宽度;
    屏幕Y = (1.0f - y) * 0.5f * 屏幕高度;
    
    return true;
}

float 计算距离(float x1, float y1, float z1, float x2, float y2, float z2) {
    float dx = x2 - x1;
    float dy = y2 - y1;
    float dz = z2 - z1;
    float 原始距离 = sqrt(dx*dx + dy*dy + dz*dz);
    return 原始距离 / 100.0f;
}

bool ReadFTransform(uintptr_t Address, FTransform& Transform) {
    return Core->Read(Address, &Transform, sizeof(FTransform));
}

bool 读取敌人骨骼(uintptr_t 对象地址, 敌人数据& 敌人, float* 视图矩阵, int 屏幕宽度, int 屏幕高度);

void GetClassName(char *Name, long int GNameAddress, int id) {
    uintptr_t FNameEntry = Core->Read<uintptr_t>(Core->Read<uintptr_t>(GNameAddress + (id / 0x4000) * 0x8) + (id % 0x4000) * 0x8);
    Core->Read(FNameEntry + 0xC, Name, 64);
}

// 添加计算旋转坐标的函数
坐标 rotateCoord(坐标 目标坐标, 坐标 自身坐标) {
    坐标 相对坐标;
    相对坐标.X = 目标坐标.X - 自身坐标.X;
    相对坐标.Y = 目标坐标.Y - 自身坐标.Y;
    相对坐标.Z = 目标坐标.Z - 自身坐标.Z;
    
    // 计算水平角度 (Yaw)
    相对坐标.X = atan2(相对坐标.Y, 相对坐标.X) * (180.0f / M_PI);
    
    // 计算垂直角度 (Pitch)
    float 水平距离 = sqrt(相对坐标.X * 相对坐标.X + 相对坐标.Y * 相对坐标.Y);
    相对坐标.Y = atan2(相对坐标.Z, 水平距离) * (180.0f / M_PI);
    
    return 相对坐标;
}

// 添加获取武器名称的函数
const char* GetHolGunItem(int 武器ID) {
    // 这里可以根据武器ID返回对应的武器名称
    // 暂时先用ID代替，后续可以扩展为具体武器名称
    static char 武器名称[32];
    snprintf(武器名称, sizeof(武器名称), "%d", 武器ID);
    return 武器名称;
}

#define PI 3.141592653589793238
typedef unsigned int ADDRESS;
typedef char PACKAGENAME;
typedef unsigned short UTF16;
typedef char UTF8;
typedef unsigned int UTF32;

#define UNI_SUR_HIGH_START (UTF32)0xD800
#define UNI_SUR_HIGH_END (UTF32)0xDBFF
#define UNI_SUR_LOW_START (UTF32)0xDC00
#define UNI_SUR_LOW_END (UTF32)0xDFFF
// Some fundamental constants
#define UNI_REPLACEMENT_CHAR (UTF32)0x0000FFFD
#define UNI_MAX_BMP (UTF32)0x0000FFFF
#define UNI_MAX_UTF16 (UTF32)0x0010FFFF
#define UNI_MAX_UTF32 (UTF32)0x7FFFFFFF
#define UNI_MAX_LEGAL_UTF32 (UTF32)0x0010FFFF

void getUTF8(UTF8 * buf, unsigned long namepy) {
    UTF16 buf16[16] = { 0 };
    Core->Read(namepy, buf16, 28);
    UTF16 *pTempUTF16 = buf16;
    UTF8 *pTempUTF8 = buf;
    UTF8 *pUTF8End = pTempUTF8 + 32;
    while (pTempUTF16 < pTempUTF16 + 28) {
        if (*pTempUTF16 <= 0x007F && pTempUTF8 + 1 < pUTF8End) {
            *pTempUTF8++ = (UTF8) * pTempUTF16;
        }
        else if (*pTempUTF16 >= 0x0080 && *pTempUTF16 <= 0x07FF && pTempUTF8 + 2 < pUTF8End) {
            *pTempUTF8++ = (*pTempUTF16 >> 6) | 0xC0;
            *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
        }
        else if (*pTempUTF16 >= 0x0800 && *pTempUTF16 <= 0xFFFF && pTempUTF8 + 3 < pUTF8End) {
            *pTempUTF8++ = (*pTempUTF16 >> 12) | 0xE0;
            *pTempUTF8++ = ((*pTempUTF16 >> 6) & 0x3F) | 0x80;
            *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
        }
        else {
            break;
        }
        pTempUTF16++;
    }
}

int GetBase(){
    地址.pid = Core->getPID ("com.tencent.tmgp.pubgmhd");
    if (地址.pid > 0 && 地址.pid < 100000) Core->initialize(地址.pid); 
    else { 地址.libUE4 = 0; return 0; }
    
    地址.libUE4 = Core->get_module_base(地址.pid,"libUE4.so");
    地址.Kernel_drive_path = Core->drive_path;

    地址.世界 = Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.libUE4 + 0x12AFBBF8) + 0x90);
    地址.Gname = Core->Read<uintptr_t>(地址.libUE4 + 0x123cfa48);
    地址.自身 = Core->Read<uintptr_t>(Core->Read<uintptr_t>(Core->Read<uintptr_t>(Core->Read<uintptr_t>( Core->Read<uintptr_t>(地址.libUE4 + 0x12AFBBF8) + 0x98) + 0x88) + 0x30) + 0x3348);
    地址.矩阵_0 = Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.libUE4 + 0x12acb840) + 0x20) + 0x270;
    地址.矩阵_1 = Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.libUE4 + 0x12AD2A60) + 0x98) + 0x750;
    uintptr_t 阵列 = Core->Read<uintptr_t>(地址.世界 + 0x30);
    
    地址.数组 = Core->Read<uintptr_t>(地址.世界 + 0xA0);
    地址.数组数量 = Core->Read<int>(地址.世界 + 0xa8);
    
    地址.自身数据.坐标.X = Core->Read<float>(Core->Read<uintptr_t>(地址.自身 + 0x278) + 0x200);
    地址.自身数据.坐标.Y = Core->Read<float>(Core->Read<uintptr_t>(地址.自身 + 0x278) + 0x204);
    地址.自身数据.坐标.Z = Core->Read<float>(Core->Read<uintptr_t>(地址.自身 + 0x278) + 0x208);

    地址.自身数据.当前血量 = Core->Read<float>(地址.自身 + 0xf08);
    地址.自身数据.最大血量 = Core->Read<float>(地址.自身 + 0xf10);
    
    地址.自身数据.开镜 = Core->Read<int>(地址.自身 + 0x16b8);
    地址.自身数据.开火 = Core->Read<int>(地址.自身 + 0x2448);
    
    地址.自身数据.状态 = Core->Read<int>(地址.自身 + 0x1588);
    
    地址.自身数据.手持 = Core->Read<int>(Core->Read<uintptr_t>(地址.自身 + 0x1018) + 0xc28);
    地址.自身数据.子弹速度 = Core->Read<int>(Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.自身 + 0x1018) + 0xae8) + 0x13fc);
    地址.自身数据.后坐力数据 = Core->Read<float>(Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.自身 + 0x1018) + 0xae8) + 0x1be8);
    地址.自身数据.手持握把 = Core->Read<int>(Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.自身 + 0x1018) + 0xae8) + 0xdd8);
    地址.自身数据.FOV =  Core->Read<float>(Core->Read<uintptr_t>(Core->Read<uintptr_t>(地址.自身 + 0x5708) + 0x608) + 0x630);
    地址.自身数据.人物高度 =  Core->Read<float>(地址.自身 + 0xf98);
    
    地址.自身数据.准星Y = Core->Read<int>(Core->Read<uintptr_t>(地址.自身 + 0x5708) + 0x5ac) - 90;
    地址.自身数据.人物高度 = Core->Read<float>(地址.自身 + 0xf98);
    
    地址.自身数据.名字 = Core->Read<uintptr_t>(地址.自身 + 0xa18);
    
    
    
    Core->Read(地址.矩阵_0, &地址.自身数据.矩阵, 16 * 4);
    
    地址.敌人数量 = 0;
    
    for (int i = 0; i < 地址.数组数量 && 地址.敌人数量 < 1000; i++){	    
        uintptr_t 对象地址 = Core->Read<uintptr_t>(地址.数组 + i * 8);
        float 敌人X = Core->Read<float>(Core->Read<uintptr_t>(对象地址 + 0x278) + 0x200);
        float 敌人Y = Core->Read<float>(Core->Read<uintptr_t>(对象地址 + 0x278) + 0x204);
        float 敌人Z = Core->Read<float>(Core->Read<uintptr_t>(对象地址 + 0x278) + 0x208);
        
        float 距离 = 计算距离(地址.自身数据.坐标.X, 地址.自身数据.坐标.Y, 地址.自身数据.坐标.Z, 
                             敌人X, 敌人Y, 敌人Z);               
        float 屏幕X, 屏幕Y;
        坐标 敌人坐标 = {敌人X, 敌人Y, 敌人Z};
        bool 在屏幕上 = WorldToScreen(敌人坐标, 地址.自身数据.矩阵, 屏幕X, 屏幕Y, ::abs_ScreenX, ::abs_ScreenY);
        
        敌人数据& 当前敌人 = 地址.敌人列表[地址.敌人数量];
        
        当前敌人.当前血量 = Core->Read<float>(对象地址 + 0xf08);
        当前敌人.最大血量 = Core->Read<float>(对象地址 + 0xf10);
        当前敌人.瞄准向量 = Core->Read<float>(对象地址 + 0x1A8);
        当前敌人.名字 = Core->Read<uintptr_t>(对象地址 + 0xA40);
        当前敌人.手持 = Core->Read<int>(Core->Read<uintptr_t>(对象地址 + 0x1018) + 0xc28);
        
        char 敌人名字[64] = {0};
        getUTF8(敌人名字, 当前敌人.名字);
        
        当前敌人.骨骼数量 = 0;
        for (int j = 0; j < 1000; j++) {
            当前敌人.骨骼数组[j].在屏幕上 = false;
            当前敌人.骨骼数组[j].屏幕坐标.X = -1;
            当前敌人.骨骼数组[j].屏幕坐标.Y = -1;
        }
        
        int ClassID = Core->Read<int>(对象地址 + 24);
        GetClassName(当前敌人.类名, 地址.Gname, ClassID);
        
         float 狗 = Core->Read<float>(对象地址 + 0x35DC); 
         if(狗 !=479.5f) continue;
         if (对象地址 == 0 || 对象地址 == 地址.自身) continue;
        if (距离 > 最大显示距离) continue;
        if (敌人X == 0 && 敌人Y == 0 && 敌人Z == 0) continue;
        
        当前敌人.对象地址 = 对象地址;
        当前敌人.世界坐标.X = 敌人X;
        当前敌人.世界坐标.Y = 敌人Y;
        当前敌人.世界坐标.Z = 敌人Z;
        当前敌人.距离 = 距离;
        当前敌人.屏幕坐标.X = 在屏幕上 ? 屏幕X : -1;
        当前敌人.屏幕坐标.Y = 在屏幕上 ? 屏幕Y : -1;
        
        if (在屏幕上 && 距离 <= 最大显示距离) {
            读取敌人骨骼(对象地址, 当前敌人, 地址.自身数据.矩阵, ::abs_ScreenX, ::abs_ScreenY);
        }
        
        地址.敌人数量++;
    }
    
// 添加被瞄预警检测逻辑
地址.被瞄数量 = 0;

for (int i = 0; i < 地址.敌人数量 && 地址.被瞄数量 < 100; i++) {
    敌人数据& 敌人 = 地址.敌人列表[i];
    if (敌人.距离 > 最大显示距离) continue;
    
    // 计算从敌人看向自己的角度
    auto enemyToSelfAngle = rotateCoord(地址.自身数据.坐标, 敌人.世界坐标);
    
    // 获取敌人的当前朝向
    FRotator enemyRotation;
    enemyRotation.Pitch = 0;
    enemyRotation.Yaw = 敌人.瞄准向量;
    enemyRotation.Roll = 0;
    enemyRotation.Clamp();
    
    // 计算角度差
    float deltaX = fabs(enemyToSelfAngle.X - enemyRotation.Yaw);
    
    // 处理360度循环
    if (deltaX > 180.0f) {
        deltaX = 360.0f - deltaX;
    }
    
    // 如果敌人在一定角度内正对着玩家，认为正在瞄准
    if (deltaX <= 30.0f) {  // 可以调整这个阈值，30度比较合理
        被瞄信息& 当前被瞄 = 地址.被瞄信息列表[地址.被瞄数量];
        当前被瞄.距离 = 敌人.距离;
        当前被瞄.名字 = 敌人.名字;
        当前被瞄.瞄准武器 = 敌人.手持;
        strncpy(当前被瞄.武器名称, GetHolGunItem(敌人.手持), sizeof(当前被瞄.武器名称));
        当前被瞄.瞄准部位 = 1;
        
        // 获取敌人名字
        char 敌人名字[64] = {0};
        getUTF8(敌人名字, 敌人.名字);
        strncpy(当前被瞄.敌人名字, 敌人名字, sizeof(当前被瞄.敌人名字));
        
        地址.被瞄数量++;
    }
}
    
    if(!running)
        delete Core;
    return 1;
}

bool 读取敌人骨骼(uintptr_t 对象地址, 敌人数据& 敌人, float* 视图矩阵, int 屏幕宽度, int 屏幕高度) {
    bool 敌人在屏幕上 = (敌人.屏幕坐标.X > 0 && 敌人.屏幕坐标.Y > 0 && 
                        敌人.屏幕坐标.X < 屏幕宽度 && 敌人.屏幕坐标.Y < 屏幕高度);
    
    if (!敌人在屏幕上) {
        敌人.骨骼数量 = 0;
        for (int i = 0; i < 1000; i++) {
            敌人.骨骼数组[i].在屏幕上 = false;
            敌人.骨骼数组[i].屏幕坐标.X = -1;
            敌人.骨骼数组[i].屏幕坐标.Y = -1;
        }
        return false;
    }
    
    uintptr_t MeshOffset = Core->Read<uintptr_t>(对象地址 + 0x600);
    if (MeshOffset == 0) {
        敌人.骨骼数量 = 0;
        return false;
    }
    
    uintptr_t boneArrayBase = Core->Read<uintptr_t>(MeshOffset + 0x810);
    if (boneArrayBase == 0) {
        敌人.骨骼数量 = 0;
        return false;
    }
    
    uintptr_t boneArrayStart = boneArrayBase + 0x30;
    敌人.骨骼数量 = Core->Read<int>(MeshOffset + 0x810 + 0x8);
    
    if (敌人.骨骼数量 > 1000) 敌人.骨骼数量 = 1000;
    if (敌人.骨骼数量 <= 0) return false;
    
    FTransform ComponentTransform;
    if (!ReadFTransform(MeshOffset + 0x1f0, ComponentTransform)) {
        敌人.骨骼数量 = 0;
        return false;
    }
    
    FMatrix ComponentToWorld = TransformToMatrix(ComponentTransform);
    
    int 有效骨骼数量 = 0;
    
    for (int i = 0; i < 敌人.骨骼数量 && 有效骨骼数量 < 1000; i++) {
        
        uintptr_t boneAddr = boneArrayStart + i * 48;
        
        FTransform BoneTransform;
        if (!ReadFTransform(boneAddr, BoneTransform)) {
            continue;
        }
        
        FMatrix BoneMatrix = TransformToMatrix(BoneTransform);
        FMatrix WorldMatrix;
        MatrixMultiply(WorldMatrix, BoneMatrix, ComponentToWorld);
        
        float 骨骼X = WorldMatrix.M[3][0];
        float 骨骼Y = WorldMatrix.M[3][1];
        float 骨骼Z = WorldMatrix.M[3][2];
        
        if (骨骼X == 0 && 骨骼Y == 0 && 骨骼Z == 0) {
            continue;
        }
        
        float 骨骼距离 = 计算距离(敌人.世界坐标.X, 敌人.世界坐标.Y, 敌人.世界坐标.Z, 骨骼X, 骨骼Y, 骨骼Z);
        if (骨骼距离 > 3.0f) {
            continue;
        }
        
        float 屏幕X, 屏幕Y;
        坐标 骨骼世界坐标 = {骨骼X, 骨骼Y, 骨骼Z};
        bool 骨骼在屏幕上 = WorldToScreen(骨骼世界坐标, 视图矩阵, 屏幕X, 屏幕Y, 屏幕宽度, 屏幕高度);
        
        if (!骨骼在屏幕上 || 
            屏幕X <= 0 || 屏幕Y <= 0 || 
            屏幕X >= 屏幕宽度 || 屏幕Y >= 屏幕高度 ||
            (fabs(屏幕X - 敌人.屏幕坐标.X) < 0.1f && fabs(屏幕Y - 敌人.屏幕坐标.Y) < 0.1f)) {
            continue;
        }
        
        敌人.骨骼数组[有效骨骼数量].位置.X = 骨骼X;
        敌人.骨骼数组[有效骨骼数量].位置.Y = 骨骼Y;
        敌人.骨骼数组[有效骨骼数量].位置.Z = 骨骼Z;
        敌人.骨骼数组[有效骨骼数量].在屏幕上 = true;
        敌人.骨骼数组[有效骨骼数量].屏幕坐标.X = 屏幕X;
        敌人.骨骼数组[有效骨骼数量].屏幕坐标.Y = 屏幕Y;
        
        有效骨骼数量++;
    }
    
    敌人.骨骼数量 = 有效骨骼数量;
    
    return 有效骨骼数量 > 0;
}

void Draw3DCornerBox(ImDrawList* draw, 敌人数据& 敌人, float* 矩阵, int 屏幕宽度, int 屏幕高度) {
    if (!draw) return;

    坐标 origin = 敌人.世界坐标;
    
    float 大小比例 = 1.0f;
    if (敌人.距离 > 100.0f) {
        大小比例 = 100.0f / 敌人.距离;
    }
    大小比例 = std::max(0.4f, std::min(1.2f, 大小比例));
    
    const float fixedSize = 50.0f * 大小比例;
    坐标 BoxExtent = {fixedSize, fixedSize, fixedSize * 1.8f};

    坐标 points[8] = {
        {origin.X - BoxExtent.X, origin.Y - BoxExtent.Y, origin.Z - BoxExtent.Z},
        {origin.X - BoxExtent.X, origin.Y + BoxExtent.Y, origin.Z - BoxExtent.Z},
        {origin.X + BoxExtent.X, origin.Y + BoxExtent.Y, origin.Z - BoxExtent.Z},
        {origin.X + BoxExtent.X, origin.Y - BoxExtent.Y, origin.Z - BoxExtent.Z},
        {origin.X - BoxExtent.X, origin.Y - BoxExtent.Y, origin.Z + BoxExtent.Z},
        {origin.X - BoxExtent.X, origin.Y + BoxExtent.Y, origin.Z + BoxExtent.Z},
        {origin.X + BoxExtent.X, origin.Y + BoxExtent.Y, origin.Z + BoxExtent.Z},
        {origin.X + BoxExtent.X, origin.Y - BoxExtent.Y, origin.Z + BoxExtent.Z}
    };

    ImU32 角颜色[8] = {
        IM_COL32(255, 0, 0, 255),
        IM_COL32(0, 255, 0, 255),
        IM_COL32(0, 0, 255, 255),
        IM_COL32(255, 255, 0, 255),
        IM_COL32(255, 0, 255, 255),
        IM_COL32(0, 255, 255, 255),
        IM_COL32(255, 165, 0, 255),
        IM_COL32(128, 128, 128, 255)
    };

    屏幕坐标 screenPoints[8];
    bool allPointsVisible = true;
    for (int i = 0; i < 8; i++) {
        if (!WorldToScreen(points[i], 矩阵, screenPoints[i].X, screenPoints[i].Y, 屏幕宽度, 屏幕高度)) {
            allPointsVisible = false;
            break;
        }
    }
    
    if (!allPointsVisible) return;

    float minX = screenPoints[0].X, maxX = screenPoints[0].X;
    float minY = screenPoints[0].Y, maxY = screenPoints[0].Y;
    for (int i = 1; i < 8; i++) {
        minX = std::min(minX, screenPoints[i].X);
        maxX = std::max(maxX, screenPoints[i].X);
        minY = std::min(minY, screenPoints[i].Y);
        maxY = std::max(maxY, screenPoints[i].Y);
    }
    
    float 动态线条粗细 = 1.2f;
    if (敌人.距离 > 50.0f) {
        动态线条粗细 = 1.0f;
    }
    if (敌人.距离 > 100.0f) {
        动态线条粗细 = 0.8f;
    }
    动态线条粗细 = std::max(0.6f, std::min(1.5f, 动态线条粗细));

    struct Edge {
        int from, to;
    };

    Edge edges[12] = {
        {0, 1}, {1, 2}, {2, 3}, {3, 0},
        {4, 5}, {5, 6}, {6, 7}, {7, 4},
        {0, 4}, {1, 5}, {2, 6}, {3, 7}
    };

    for (int i = 0; i < 12; ++i) {
        int from = edges[i].from;
        int to = edges[i].to;
        
        ImVec2 pFrom = ImVec2(screenPoints[from].X, screenPoints[from].Y);
        ImVec2 pTo = ImVec2(screenPoints[to].X, screenPoints[to].Y);
        
        float dx = pTo.x - pFrom.x;
        float dy = pTo.y - pFrom.y;
        float edgeLength = sqrtf(dx * dx + dy * dy);
        
        if (edgeLength > 0.01f) {
            dx /= edgeLength;
            dy /= edgeLength;
            
            int 段数 = static_cast<int>(edgeLength / 10.0f);
            段数 = std::max(4, std::min(12, 段数));
            
            float 段长度 = edgeLength / 段数;
            
            float 渐变强度 = 0.7f;
            if (敌人.距离 < 30.0f) {
                渐变强度 = 0.3f;
            } else if (敌人.距离 < 60.0f) {
                渐变强度 = 0.5f;
            }
            
            for (int j = 0; j < 段数; ++j) {
                float 起点比例 = (float)j / 段数;
                float 终点比例 = (float)(j + 1) / 段数;
                
                ImVec2 段起点 = ImVec2(
                    pFrom.x + dx * edgeLength * 起点比例,
                    pFrom.y + dy * edgeLength * 起点比例
                );
                
                ImVec2 段终点 = ImVec2(
                    pFrom.x + dx * edgeLength * 终点比例,
                    pFrom.y + dy * edgeLength * 终点比例
                );
                
                float 中心点比例 = (起点比例 + 终点比例) / 2.0f;
                
                float 透明度 = 1.0f;
                
                if (中心点比例 < 0.5f) {
                    透明度 = 1.0f - (中心点比例 / 0.5f) * 渐变强度;
                } else {
                    透明度 = 1.0f - ((1.0f - 中心点比例) / 0.5f) * 渐变强度;
                }
                
                透明度 = std::max(0.3f, std::min(1.0f, 透明度));
                
                float 混合比例 = 中心点比例;
                ImU32 起点色 = 角颜色[from];
                ImU32 终点色 = 角颜色[to];
                
                int r1 = (起点色 >> IM_COL32_R_SHIFT) & 0xFF;
                int g1 = (起点色 >> IM_COL32_G_SHIFT) & 0xFF;
                int b1 = (起点色 >> IM_COL32_B_SHIFT) & 0xFF;
                
                int r2 = (终点色 >> IM_COL32_R_SHIFT) & 0xFF;
                int g2 = (终点色 >> IM_COL32_G_SHIFT) & 0xFF;
                int b2 = (终点色 >> IM_COL32_B_SHIFT) & 0xFF;
                
                int r = static_cast<int>(r1 * (1.0f - 混合比例) + r2 * 混合比例);
                int g = static_cast<int>(g1 * (1.0f - 混合比例) + g2 * 混合比例);
                int b = static_cast<int>(b1 * (1.0f - 混合比例) + b2 * 混合比例);
                
                int a = static_cast<int>(255 * 透明度);
                
                r = std::max(0, std::min(255, r));
                g = std::max(0, std::min(255, g));
                b = std::max(0, std::min(255, b));
                a = std::max(100, std::min(255, a));
                
                ImU32 混合颜色 = IM_COL32(r, g, b, a);
                
                draw->AddLine(段起点, 段终点, 混合颜色, 动态线条粗细);
            }
        }
    }
}
