

#include <map>
#include <atomic>
#include <thread>
#include <mutex>
#include <cmath>
#include <cfloat>
#include <cstdlib>
#include <cstdio>

extern int 目标FPS;
extern bool FPS限制启用;

void Layout_tick_UI(bool* main_thread_flag) {
    static bool 显示中心点 = false;
    static bool 显示敌人连线 = false;
    static bool 显示距离 = false;
    static bool 显示骨骼点 = false;
    static bool 骨骼索引 = false;
    static bool 显示类名 = false;
    static bool 显示最近目标连线 = false;
    static int 最大骨骼显示数量 = 70;
    static bool 显示3D框 = false;
    static bool 显示敌人名字 = false;
    static bool 显示生命值 = false;
    static bool 显示敌人方向线 = false;
    static float 方向线长度 = 50.0f;
    static float 水平线长度 = 30.0f;
    static bool 显示可移动圆 = false;
    static ImVec2 圆位置 = ImVec2(::abs_ScreenX / 2.0f, ::abs_ScreenY / 2.0f);
    static float 圆半径 = 50.0f;
    static float 圆颜色[4] = {1.0f, 0.0f, 1.0f, 1.0f};
    static bool 正在拖动圆 = false;
    static float 瞄准平滑度 = 0.7f;
    static bool 持续瞄准 = false;
    static int 瞄准频率 = 30;
    static int 屏幕方向 = 0;
    static char 触摸调试信息[256] = "";
    static char 瞄准调试信息[256] = "";
    
    // 添加被瞄预警开关
    static bool 显示被瞄预警 = true;

    int 最近目标索引 = -1;
    float 最近目标距离 = FLT_MAX;
    float 屏幕中心点X = ::abs_ScreenX / 2.0f;
    float 屏幕中心点Y = ::abs_ScreenY / 2.0f;

    for (int i = 0; i < 地址.敌人数量; i++) {
        敌人数据& 敌人 = 地址.敌人列表[i];
        if (敌人.距离 > 最大显示距离) continue;
        
        if (敌人.屏幕坐标.X > 0 && 敌人.屏幕坐标.Y > 0 && 
            敌人.屏幕坐标.X < ::abs_ScreenX && 敌人.屏幕坐标.Y < ::abs_ScreenY) {
            float 屏幕距离 = sqrt(pow(敌人.屏幕坐标.X - 屏幕中心点X, 2) + pow(敌人.屏幕坐标.Y - 屏幕中心点Y, 2));
            if (屏幕距离 < 最近目标距离) {
                最近目标距离 = 屏幕距离;
                最近目标索引 = i;
            }
        }
    }

    {
        std::lock_guard<std::mutex> lock(触摸互斥锁);
        当前瞄准参数.屏幕方向 = 屏幕方向;
        当前瞄准参数.实际方向 = 屏幕方向;
        当前瞄准参数.screenWidth = displayInfo.width;
        当前瞄准参数.screenHeight = displayInfo.height;
        当前瞄准参数.圆位置 = 圆位置;
        当前瞄准参数.圆半径 = 圆半径;
        当前瞄准参数.瞄准平滑度 = 瞄准平滑度;
        当前瞄准参数.最近目标索引 = 最近目标索引;
        当前瞄准参数.屏幕中心点X = 屏幕中心点X;
        当前瞄准参数.屏幕中心点Y = 屏幕中心点Y;
        当前瞄准参数.持续瞄准 = 持续瞄准;
        当前瞄准参数.瞄准频率 = 瞄准频率;
    }

    static bool 上次持续瞄准状态 = false;
    if (持续瞄准 && !上次持续瞄准状态) {
        启动触摸线程();
    } else if (!持续瞄准 && 上次持续瞄准状态) {
        停止触摸线程();
    }
    上次持续瞄准状态 = 持续瞄准;

    ImGui::SetNextWindowSize(ImVec2(1000, 1000), ImGuiCond_Once);
    if (ImGui::Begin("TG @BrotherHua")) {
        if (::permeate_record_ini) {
            ImGui::SetWindowPos({LastCoordinate.Pos_x, LastCoordinate.Pos_y});
            ImGui::SetWindowSize({LastCoordinate.Size_x, LastCoordinate.Size_y});
            permeate_record_ini = false;
        }
        
        ImGui::Text("ESP :");
        ImGui::Checkbox("3D框", &显示3D框);
        ImGui::SameLine(500.0f);
        ImGui::Checkbox("显示距离", &显示距离);
        
        ImGui::Checkbox("生命值条", &显示生命值);
        ImGui::SameLine(500.0f);
        ImGui::Checkbox("信息线", &显示敌人方向线);
        
        ImGui::Checkbox("敌人名字", &显示敌人名字);
        ImGui::SameLine(500.0f);
        ImGui::Checkbox("屏幕中心点", &显示中心点);
        
        ImGui::Checkbox("被瞄预警", &显示被瞄预警);
        
        ImGui::Text("触摸瞄准 :");
        ImGui::Checkbox("启动自瞄", &持续瞄准);
        ImGui::SameLine(250.0f);
        ImGui::RadioButton("横屏", &屏幕方向, 0);
        ImGui::SameLine(500.0f);
        ImGui::RadioButton("反向横屏", &屏幕方向, 1);
        
        ImGui::Checkbox("目标选择器", &显示最近目标连线);
        ImGui::SameLine(500.0f);
        ImGui::Checkbox("触摸范围", &显示可移动圆);
        
        if (显示可移动圆) {
            ImGui::Text("圆半径");
            ImGui::SameLine();
            ImGui::ColorEdit4("##圆颜色", 圆颜色, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
            ImGui::SameLine(200.0f);
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##圆半径", &圆半径, 50.0f, 600.0f);
        }
        
        if (持续瞄准) {
            ImGui::Text("更新频率(ms)");
            ImGui::SameLine(200.0f);
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderInt("##更新频率(ms)", &瞄准频率, 1, 50);
            ImGui::Text("平滑度");
            ImGui::SameLine(200.0f);
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##自瞄节点数", &瞄准平滑度, 0.1f, 2.0f, "%.2f");
        }
        
        ImGui::Separator();
        ImGui::Text("ESP距离限制");
        ImGui::SameLine(200.0f);
        ImGui::SetNextItemWidth(-1);
        ImGui::SliderFloat("##绘制最大距离", &最大显示距离, 4.0f, 500.0f);
        ImGui::Text("FPS:");
        ImGui::SameLine(200.0f);
        ImGui::SetNextItemWidth(-1);
        ImGui::SliderInt("##FPS", &目标FPS, 30, 144);
        
        if (ImGui::CollapsingHeader("debug")) {
            ImGui::Checkbox("显示类名", &显示类名);
            ImGui::SameLine(500.0f);
            ImGui::Checkbox("显示敌人连线 <中间开始到敌人坐标", &显示敌人连线);
            ImGui::Checkbox("骨骼点", &显示骨骼点);
            ImGui::SameLine(500.0f);
            ImGui::Checkbox("骨骼点id", &骨骼索引);
            
            if (显示敌人方向线) {                 
                ImGui::Text("斜线长度");
                ImGui::SameLine();
                ImGui::SetNextItemWidth(-1.0f);
                ImGui::SliderFloat("##斜线长度", &方向线长度, 20.0f, 200.0f, "%.0f");                
                ImGui::Text("水平线长度");
                ImGui::SameLine();
                ImGui::SetNextItemWidth(-1.0f);
                ImGui::SliderFloat("##水平线长度", &水平线长度, 10.0f, 100.0f, "%.0f");
            }
            
            ImGui::Text("  ");
            ImGui::SameLine();
            
            if (ImGui::CollapsingHeader("调试信息")) {
                ImGui::Text("Drive path:%s", 地址.Kernel_drive_path);
                ImGui::SameLine(+500.0f);
                ImGui::Text("Game Pid:%d", 地址.pid);
                ImGui::Text("libUE4:0x%lx", 地址.libUE4);
                ImGui::SameLine(+500.0f);
                ImGui::Text("Gname:_%lx", 地址.Gname);
                ImGui::Text("世界地址:～%lx", 地址.世界);
                ImGui::SameLine(+500.0f);
                ImGui::Text("自身地址:～%lx", 地址.自身);
                ImGui::Text("数组地址:～%lx", 地址.数组);
                ImGui::SameLine(+500.0f);
                ImGui::Text("数组数量:～%d", 地址.数组数量);
                ImGui::SameLine();
                ImGui::Text("敌人数量:～%d", 地址.敌人数量);
                ImGui::Text("被瞄数量:～%d", 地址.被瞄数量);
                ImGui::Text("自己坐标:");
                ImGui::Text("x~%f", 地址.自身数据.坐标.X);
                ImGui::SameLine(+250.0f);
                ImGui::Text("y～%f", 地址.自身数据.坐标.Y);
                ImGui::SameLine(+500.0f);
                ImGui::Text("z～%f", 地址.自身数据.坐标.Z);
            }
        }

        if (持续瞄准) {
            if (触摸线程运行中.load()) {
                if (最近目标索引 == -1) {
                    ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "持续瞄准: 无目标");
                } else {
                    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "持续瞄准: 运行中");
                }
            } else {
                ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "持续瞄准: 已停止");
            }
        }

        if (ImGui::Button("结束程序", ImVec2(-1, 80))) {
            停止触摸线程();
            running = false;
            exit(0);
        }
        
        ImGui::End();
    }

    // 显示被瞄预警信息
    if (显示被瞄预警 && 地址.被瞄数量 > 0) {
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        float startX = 10.0f;
        float startY = 10.0f;
        float lineHeight = 20.0f;
        
        // 绘制标题
        draw_list->AddText(ImVec2(startX, startY), IM_COL32(255, 0, 0, 255), "被瞄预警:");
        startY += lineHeight;
        
        for (int i = 0; i < 地址.被瞄数量; i++) {
            被瞄信息& 被瞄 = 地址.被瞄信息列表[i];
            
            char 预警文本[128];
            snprintf(预警文本, sizeof(预警文本), "%s 使用 %s 瞄准你 (%.1fm)", 
                    被瞄.敌人名字, 被瞄.武器名称, 被瞄.距离);
            
            draw_list->AddText(ImVec2(startX, startY), IM_COL32(255, 100, 100, 255), 预警文本);
            startY += lineHeight;
            
            // 如果显示太多，就停止
            if (startY > ::abs_ScreenY - 100) break;
        }
    }

    if (显示可移动圆) {
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        ImU32 color = IM_COL32(圆颜色[0]*255, 圆颜色[1]*255, 圆颜色[2]*255, 圆颜色[3]*255);
        draw_list->AddCircleFilled(圆位置, 圆半径, color);
        draw_list->AddCircle(圆位置, 圆半径, IM_COL32(255, 255, 255, 255), 0, 2.0f);
        
        ImVec2 mouse_pos = ImGui::GetMousePos();
        bool is_mouse_clicked = ImGui::IsMouseClicked(0);
        bool is_mouse_down = ImGui::IsMouseDown(0);
        bool is_mouse_released = ImGui::IsMouseReleased(0);
        
        float distance_to_center = sqrt(pow(mouse_pos.x - 圆位置.x, 2) + pow(mouse_pos.y - 圆位置.y, 2));
        bool is_mouse_over_circle = distance_to_center <= 圆半径;
        
        if (is_mouse_clicked && is_mouse_over_circle) {
            正在拖动圆 = true;
        }
        
        if (正在拖动圆 && is_mouse_down) {
            圆位置 = mouse_pos;
        }
        
        if (is_mouse_released) {
            正在拖动圆 = false;
        }
        
        if (is_mouse_over_circle || 正在拖动圆) {
            char pos_text[64];
            snprintf(pos_text, sizeof(pos_text), "位置: (%.0f, %.0f)", 圆位置.x, 圆位置.y);
            ImVec2 text_size = ImGui::CalcTextSize(pos_text);
            draw_list->AddText(ImVec2(圆位置.x - text_size.x / 2, 圆位置.y - 圆半径 - text_size.y - 5),
                             IM_COL32(255, 255, 255, 255), pos_text);
        }
    }

    if (显示中心点) {
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        draw_list->AddCircleFilled(ImVec2(屏幕中心点X, 屏幕中心点Y), 5.0f, IM_COL32(255, 0, 0, 255));
    }

    if (显示最近目标连线 && 最近目标索引 != -1) {
        敌人数据& 最近敌人 = 地址.敌人列表[最近目标索引];
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        draw_list->AddLine(ImVec2(屏幕中心点X, 屏幕中心点Y), ImVec2(最近敌人.屏幕坐标.X, 最近敌人.屏幕坐标.Y),
                         IM_COL32(255, 0, 0, 255), 2.0f);
    }

    static std::map<uintptr_t, float> 动画计时器;
    static std::map<uintptr_t, bool> 动画方向;
    static bool 上次显示状态 = false;
    static std::map<uintptr_t, float> prevHealthPercent;
    static std::map<uintptr_t, int> prevCurHP;
    static std::map<uintptr_t, int> prevMaxHP;
    static std::map<uintptr_t, ImColor> prevHealthColor;
    static std::map<uintptr_t, float> lastHealthPercent;

    if (显示生命值 || !动画计时器.empty()) {
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        
        if (显示生命值 && !上次显示状态) {
            for (int i = 0; i < 地址.敌人数量; i++) {
                敌人数据& 敌人 = 地址.敌人列表[i];
                if (敌人.距离 <= 最大显示距离 && 敌人.屏幕坐标.X > 0 && 敌人.屏幕坐标.Y > 0 && 
                    敌人.屏幕坐标.X < ::abs_ScreenX && 敌人.屏幕坐标.Y < ::abs_ScreenY) {
                    uintptr_t 敌人地址 = (uintptr_t)敌人.对象地址;
                    动画计时器[敌人地址] = 动画计时器.count(敌人地址) ? 动画计时器[敌人地址] : 0.0f;
                    动画方向[敌人地址] = true;
                }
            }
        }
        
        if (!显示生命值 && 上次显示状态) {
            for (int i = 0; i < 地址.敌人数量; i++) {
                敌人数据& 敌人 = 地址.敌人列表[i];
                if (敌人.距离 <= 最大显示距离 && 敌人.屏幕坐标.X > 0 && 敌人.屏幕坐标.Y > 0 && 
                    敌人.屏幕坐标.X < ::abs_ScreenX && 敌人.屏幕坐标.Y < ::abs_ScreenY) {
                    uintptr_t 敌人地址 = (uintptr_t)敌人.对象地址;
                    if (!动画计时器.count(敌人地址)) {
                        动画计时器[敌人地址] = 1.0f;
                    }
                    动画方向[敌人地址] = false;
                }
            }
        }
        
        上次显示状态 = 显示生命值;
        std::vector<uintptr_t> 需要移除的敌人;
        
        for (auto& 动画项 : 动画计时器) {
            uintptr_t 敌人地址 = 动画项.first;
            float& 计时器 = 动画项.second;
            bool 正在打开 = 动画方向[敌人地址];
            
            if (正在打开) {
                if (计时器 < 1.0f) {
                    计时器 += 0.08f;
                    计时器 = std::min(1.0f, 计时器);
                }
            } else {
                if (计时器 > 0.0f) {
                    计时器 -= 0.08f;
                    计时器 = std::max(0.0f, 计时器);
                } else {
                    需要移除的敌人.push_back(敌人地址);
                    continue;
                }
            }
        }
        
        for (int i = 0; i < 地址.敌人数量; i++) {
            敌人数据& 敌人 = 地址.敌人列表[i];
            if (敌人.距离 > 最大显示距离) continue;
            
            if (敌人.屏幕坐标.X > 0 && 敌人.屏幕坐标.Y > 0 && 
                敌人.屏幕坐标.X < ::abs_ScreenX && 敌人.屏幕坐标.Y < ::abs_ScreenY) {
                
                uintptr_t 敌人地址 = (uintptr_t)敌人.对象地址;
                if (显示生命值 && !动画计时器.count(敌人地址)) {
                    动画计时器[敌人地址] = 0.001f;
                    动画方向[敌人地址] = true;
                }
                
                if (!动画计时器.count(敌人地址)) continue;
                
                float 计时器 = 动画计时器[敌人地址];
                bool 正在打开 = 动画方向[敌人地址];
                float 动画进度 = 1.0f - std::pow(1.0f - 计时器, 2.0f);
                if (!正在打开) 动画进度 = 计时器;
                
                int CurHP = (int)std::max(0.0f, std::min(敌人.当前血量, 敌人.最大血量));
                int MaxHP = (int)敌人.最大血量;
                float HealthPercent = (MaxHP > 0) ? ((float)CurHP / (float)MaxHP * 100.f) : 0.0f;
                
                if (prevHealthPercent.find(敌人地址) == prevHealthPercent.end()) {
                    prevHealthPercent[敌人地址] = HealthPercent;
                }
                if (prevCurHP.find(敌人地址) == prevCurHP.end()) {
                    prevCurHP[敌人地址] = CurHP;
                }
                if (prevMaxHP.find(敌人地址) == prevMaxHP.end()) {
                    prevMaxHP[敌人地址] = MaxHP;
                }
                if (prevHealthColor.find(敌人地址) == prevHealthColor.end()) {
                    prevHealthColor[敌人地址] = ImColor(0, 255, 100, 220);
                }
                
                float& prevHP = prevHealthPercent[敌人地址];
                int& prevCur = prevCurHP[敌人地址];
                int& prevMax = prevMaxHP[敌人地址];
                ImColor& prevColor = prevHealthColor[敌人地址];
                
                float animSpeed = 0.1f;
                if (std::abs(prevHP - HealthPercent) > 1.0f) {
                    prevHP = prevHP + (HealthPercent - prevHP) * animSpeed;
                    prevCur = prevCur + (CurHP - prevCur) * animSpeed;
                    prevMax = prevMax + (MaxHP - prevMax) * animSpeed;
                } else {
                    prevHP = HealthPercent;
                    prevCur = CurHP;
                    prevMax = MaxHP;
                }
                
                ImColor targetColor;
                if (HealthPercent > 75.0f) targetColor = ImColor(0, 255, 200, 220);
                else if (HealthPercent > 50.0f) targetColor = ImColor(255, 255, 0, 220);
                else if (HealthPercent > 25.0f) targetColor = ImColor(255, 150, 0, 220);
                else targetColor = ImColor(255, 50, 50, 220);
                
                prevColor = ImColor(prevColor.Value.x + (targetColor.Value.x - prevColor.Value.x) * animSpeed,
                                  prevColor.Value.y + (targetColor.Value.y - prevColor.Value.y) * animSpeed,
                                  prevColor.Value.z + (targetColor.Value.z - prevColor.Value.z) * animSpeed,
                                  prevColor.Value.w + (targetColor.Value.w - prevColor.Value.w) * animSpeed);
                
                long HPColor = ImGui::ColorConvertFloat4ToU32(prevColor);
                
                屏幕坐标 头部坐标;
                bool 有头部 = false;
                for (int j = 0; j < 敌人.骨骼数量; j++) {
                    骨骼数据& 骨骼 = 敌人.骨骼数组[j];
                    if (骨骼.在屏幕上 && j == 5) {
                        头部坐标 = 骨骼.屏幕坐标;
                        float 头部偏移 = 10.0f + (40.0f * (1.0f - std::min(1.0f, 敌人.距离 / 30.0f)));
                        头部坐标.Y -= 头部偏移;
                        有头部 = true;
                        break;
                    }
                }
                
                if (!有头部) {
                    头部坐标 = 敌人.屏幕坐标;
                    float 头部偏移 = 15.0f + (25.0f * (1.0f - std::min(1.0f, 敌人.距离 / 30.0f)));
                    头部坐标.Y -= 头部偏移;
                }
                
                float 距离因子 = std::min(1.0f, 敌人.距离 / 100.0f);
                float 垂直偏移 = 35.0f * (1.0f - 距离因子 * 0.5f);
                垂直偏移 = std::max(17.5f, 垂直偏移);
                
                float 目标宽度 = 180.0f;
                float 当前宽度 = 目标宽度 * 动画进度;
                float barHeight = 10.0f;
                float barX = 头部坐标.X - 当前宽度 / 2;
                float barY = 头部坐标.Y - 垂直偏移;
                
                ImVec2 barStart = {barX, barY};
                ImVec2 barEnd = {barX + 当前宽度, barY + barHeight};
                float cornerRadius = 5.0f * 动画进度;
                float filledWidth = (prevHP / 100.f) * 当前宽度;
                ImVec2 filledStart = barStart;
                ImVec2 filledEnd = {barStart.x + filledWidth, barStart.y + barHeight};
                
                float 发光强度 = 动画进度;
                for (int glow = 0; glow < 3; glow++) {
                    float offset = glow * 2.0f;
                    ImVec2 outerGlowStart = {barStart.x - offset, barStart.y - offset};
                    ImVec2 outerGlowEnd = {barEnd.x + offset, barEnd.y + offset};
                    long outerGlowColor = (HPColor & 0x00FFFFFF) | ((int)((50 - glow*15) * 发光强度) << 24);
                    if (outerGlowStart.x < outerGlowEnd.x && outerGlowStart.y < outerGlowEnd.y) {
                        draw_list->AddRectFilled(outerGlowStart, outerGlowEnd, outerGlowColor, cornerRadius + offset);
                    }
                }
                
                if (barStart.x < barEnd.x && barStart.y < barEnd.y) {
                    draw_list->AddRectFilled(barStart, barEnd, IM_COL32(20, 20, 30, (int)(200 * 动画进度)), cornerRadius);
                }
                
                if (filledWidth > 0 && filledStart.x < filledEnd.x && filledStart.y < filledEnd.y) {
                    if (filledWidth > cornerRadius * 2) {
                        draw_list->AddRectFilled(filledStart, filledEnd, HPColor, cornerRadius);
                    } else {
                        draw_list->AddRectFilled(filledStart, filledEnd, HPColor, 0.0f);
                    }
                }
                
                if (barStart.x < barEnd.x && barStart.y < barEnd.y) {
                    draw_list->AddRect(barStart, barEnd, IM_COL32(0, 0, 0, (int)(200 * 动画进度)), cornerRadius, 0, 0.8f);
                }
                
                if (lastHealthPercent.find(敌人地址) == lastHealthPercent.end()) {
                    lastHealthPercent[敌人地址] = HealthPercent;
                }
                float& lastHP = lastHealthPercent[敌人地址];
                lastHP = HealthPercent;
            }
        }
        
        for (uintptr_t 敌人地址 : 需要移除的敌人) {
            动画计时器.erase(敌人地址);
            动画方向.erase(敌人地址);
            prevHealthPercent.erase(敌人地址);
            prevCurHP.erase(敌人地址);
            prevMaxHP.erase(敌人地址);
            prevHealthColor.erase(敌人地址);
            lastHealthPercent.erase(敌人地址);
        }
    }

    if (显示敌人连线 || 显示骨骼点 || 显示3D框 || 显示敌人方向线 || 显示敌人名字) { 
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        
        for (int i = 0; i < 地址.敌人数量; i++) {
            敌人数据& 敌人 = 地址.敌人列表[i];
            if (敌人.距离 > 最大显示距离) continue;
            
            if (敌人.屏幕坐标.X > 0 && 敌人.屏幕坐标.Y > 0 && 
                敌人.屏幕坐标.X < ::abs_ScreenX && 敌人.屏幕坐标.Y < ::abs_ScreenY) {
                
                if (显示敌人连线 && i != 最近目标索引) {
                    draw_list->AddLine(ImVec2(屏幕中心点X, 屏幕中心点Y), ImVec2(敌人.屏幕坐标.X, 敌人.屏幕坐标.Y),
                                     IM_COL32(0, 255, 0, 255), 2.0f);
                }
                
                if (显示距离) {
                    char 距离文本[32];
                    snprintf(距离文本, sizeof(距离文本), "%.1fm", 敌人.距离);
                    ImVec2 文本尺寸 = ImGui::CalcTextSize(距离文本);
                    draw_list->AddText(ImVec2(敌人.屏幕坐标.X - 文本尺寸.x / 2, 敌人.屏幕坐标.Y + 15),
                                     IM_COL32(255, 255, 255, 255), 距离文本);
                }
                
                if (显示类名) {
                    ImVec2 类名文本尺寸 = ImGui::CalcTextSize(敌人.类名);
                    draw_list->AddText(ImVec2(敌人.屏幕坐标.X - 类名文本尺寸.x / 2, 敌人.屏幕坐标.Y + 35),
                                     IM_COL32(255, 200, 0, 255), 敌人.类名);
                }
                
                if (显示3D框) {
                    Draw3DCornerBox(draw_list, 敌人, 地址.自身数据.矩阵, ::abs_ScreenX, ::abs_ScreenY);
                }
                
// 计算长度（无论开关都要计算，用于名字定位）
float 实际斜线长度, 实际水平线长度;
if (敌人.距离 < 10.0f) {
    实际斜线长度 = 方向线长度 * 2.5f;
    实际水平线长度 = 水平线长度 * 2.5f;
} else if (敌人.距离 < 30.0f) {
    实际斜线长度 = 方向线长度;
    实际水平线长度 = 水平线长度;
} else if (敌人.距离 < 60.0f) {
    实际斜线长度 = 方向线长度 * 0.7f;
    实际水平线长度 = 水平线长度 * 0.7f;
} else {
    实际斜线长度 = 方向线长度 * 0.4f;
    实际水平线长度 = 水平线长度 * 0.4f;
}

// 信息线开关
if (显示敌人方向线) {
    float endX1 = 敌人.屏幕坐标.X + 实际斜线长度 * cos(M_PI / 4);
    float endY1 = 敌人.屏幕坐标.Y - 实际斜线长度 * sin(M_PI / 4);
    float endX2 = endX1 + 实际水平线长度;
    float endY2 = endY1;
    
    draw_list->AddLine(ImVec2(敌人.屏幕坐标.X, 敌人.屏幕坐标.Y), ImVec2(endX1, endY1),
                     IM_COL32(0, 150, 255, 255), 2.0f);
    draw_list->AddLine(ImVec2(endX1, endY1), ImVec2(endX2, endY2),
                     IM_COL32(0, 255, 100, 255), 2.0f);
}

if (显示敌人名字) {
    char 敌人名字[64] = {0};
    getUTF8(敌人名字, 敌人.名字);
    
    // 计算水平线位置（无论信息线是否显示）
    float endX1 = 敌人.屏幕坐标.X + 实际斜线长度 * cos(M_PI / 4);
    float endX2 = endX1 + 实际水平线长度;
    float endY1 = 敌人.屏幕坐标.Y - 实际斜线长度 * sin(M_PI / 4);
    
    // 名字始终显示在水平线中间上方（上调了5个像素）
    float 名字位置X = (endX1 + endX2) / 2;
    float 名字位置Y = endY1 - 13;  // 从原来的-8改为-13，上调了5个像素
    
    ImVec2 文本尺寸 = ImGui::CalcTextSize(敌人名字);
    
    // 绘制敌人名字
    draw_list->AddText(
        ImVec2(名字位置X - 文本尺寸.x/2, 名字位置Y - 文本尺寸.y/2),
        IM_COL32(255, 255, 255, 255),
        敌人名字
    );
}
                
                if (显示骨骼点 && 敌人.骨骼数量 > 0) {
                    int 显示数量 = (敌人.骨骼数量 < 最大骨骼显示数量) ? 敌人.骨骼数量 : 最大骨骼显示数量;
                    
                    for (int j = 0; j < 显示数量; j++) {
                        骨骼数据& 骨骼 = 敌人.骨骼数组[j];
                        if (骨骼.在屏幕上 && 骨骼.屏幕坐标.X > 1 && 骨骼.屏幕坐标.Y > 1 && 
                            骨骼.屏幕坐标.X < (::abs_ScreenX - 1) && 骨骼.屏幕坐标.Y < (::abs_ScreenY - 1) && 
                            !(fabs(骨骼.屏幕坐标.X - 敌人.屏幕坐标.X) < 0.1f && fabs(骨骼.屏幕坐标.Y - 敌人.屏幕坐标.Y) < 0.1f)) {
                            
                            draw_list->AddCircleFilled(ImVec2(骨骼.屏幕坐标.X, 骨骼.屏幕坐标.Y), 2.0f,
                                                     IM_COL32(0, 255, 255, 255));
                            
                            if (骨骼索引) {
                                char 索引文本[16];
                                snprintf(索引文本, sizeof(索引文本), "%d", j);
                                ImVec2 文本尺寸 = ImGui::CalcTextSize(索引文本);
                                draw_list->AddText(ImVec2(骨骼.屏幕坐标.X - 文本尺寸.x / 2, 骨骼.屏幕坐标.Y + 6),
                                                 IM_COL32(255, 255, 0, 200), 索引文本);
                            }
                        }
                    }
                }
            }
        }
    }
}
