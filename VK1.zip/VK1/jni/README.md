本源码可以在安卓设备编译，电脑也就ndk-build
采用VulKan渲染
Android_draw文件夹和ImGui文件夹为基本库和渲染文件(小白别动)
UI在layout.h 字体等一些基本的UI可以去Draw.cpp，字体搬别人的(有需要自行更换)
Kernel.h为驱动读写文件

tg@cjsgzz